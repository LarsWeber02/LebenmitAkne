import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: Stufenzusatz()));

class Stufenzusatz extends StatelessWidget {
  final List<String> Zusatz = ['Intervallfasten', 'Sport', 'Meditieren'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(
              child: Text(
            'Stufenzusätze',
            style: TextStyle(
                fontSize: 30,
                color: Colors.white,
                decoration: TextDecoration.underline),
          )),
          backgroundColor: Color.fromRGBO(35, 112, 192, 1),
        ),
        body: Stack(
          children: <Widget>[
            Align(alignment: Alignment(0,-0.95), child: RichText(
                text: TextSpan(style: TextStyle(fontSize: 20, color: Colors.black),
                    children: [
                      TextSpan(text: 'Du willst zu deiner aktuellen Stufe eine Aufgabe hinzufügen?\n',
                          style: TextStyle(fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                      TextSpan(text: '1. Schau dir meine Vorschläge genauer an, indem du auf sie klickst.\n2. Oder du erstellst dir deinen eigenen Zusatz.')
                    ])),),
            Align(alignment: Alignment(0,0.8), child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: ListView.separated(
                    separatorBuilder: (BuildContext context, int i) {
                      return SizedBox(height: 7);
                    },
                    itemCount: Zusatz.length,
                    itemBuilder: (BuildContext, i) {
                        return Container(
                        decoration: BoxDecoration(
                          border: Border.all(width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                          borderRadius: BorderRadius.circular(5)
                        ),
                        child: ListTile(
                          contentPadding: EdgeInsets.symmetric(vertical: 20),
                            leading: Icon(
                              Icons.add,
                            ),
                            title: Text(Zusatz[i]),
                            trailing: Column(children: <Widget>[
                              if (Zusatz[i] == 'Intervallfasten')
                                Expanded(
                                    child: Container(
                                      child: Image(
                                          image: NetworkImage(
                                              'https://images.pexels.com/photos/1198264/pexels-photo-1198264.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940')),
                                    decoration: BoxDecoration(
                                      border: Border(right: BorderSide(width: 10, color: Colors.white))
                                    ),
                                    ))
                              else if (Zusatz[i] == 'Sport')
                                Expanded(
                                    child: Container(
                                      child: Image(
                                          image: NetworkImage(
                                              'https://cdn.pixabay.com/photo/2017/05/25/15/08/jogging-2343558_960_720.jpg')),
                                        decoration: BoxDecoration(
                                            border: Border(right: BorderSide(width: 10, color: Colors.white))
                                    )))
                              else if (Zusatz[i] == 'Meditieren')
                                Expanded(
                                    child: Container(
                                      child: Image(
                                          image: NetworkImage(
                                              'https://cdn.pixabay.com/photo/2016/11/22/23/29/meditate-1851165_960_720.jpg')),
                      decoration: BoxDecoration(
                      border: Border(right: BorderSide(width: 10, color: Colors.white))
                                    )))
                            ])),
                      );
                    })))
          ],
        ));
  }
}
