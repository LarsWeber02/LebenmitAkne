import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';


class FleischBerichte extends StatefulWidget {
  const FleischBerichte({Key? key}) : super(key: key);

  @override
  State<FleischBerichte> createState() => _FleischBerichteState();
}

class _FleischBerichteState extends State<FleischBerichte> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('medizinischer Fleischbericht',
        style: TextStyle(fontWeight: FontWeight.bold),),),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 50, right: 8, left: 8, top: 8),
            child: Text('Einen guten medizinischen Bericht zum Thema Fleisch und Akne habe '
                'ich nicht gefunden.',
              style: TextStyle(fontSize: 20),
              textAlign: TextAlign.center,),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 50),
            child: Text('Aber...',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('...dieser Bericht beschreibt den entzündungsfördernden Effekt von'
                ' bestimmten Fleischsorten:',
              style: TextStyle(fontSize: 20),
    textAlign: TextAlign.center,),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextButton(
              style: TextButton.styleFrom(
                primary: Colors.white,
                backgroundColor: Color.fromRGBO(35, 112, 192, 1)
              ),
              onPressed: () async{
                const url = 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5035214/';
                if(await canLaunch(url)) {
                  await launch(url,
                  enableJavaScript: true,
                  forceSafariVC: true,
                  forceWebView: true);
                } else throw 'Could not launch :(';
              },
              child: Text('Bericht',style: TextStyle(fontWeight: FontWeight.bold),),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('...dieser Bericht weist auf den Antibiotikagehalt in Fleisch mit'
                ' schlechter Qualität hin:',
              style: TextStyle(fontSize: 20),
              textAlign: TextAlign.center,),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextButton(
              style: TextButton.styleFrom(
                  primary: Colors.white,
                  backgroundColor: Color.fromRGBO(35, 112, 192, 1)
              ),
              onPressed: () async{
                const url = 'https://pubmed.ncbi.nlm.nih.gov/29537307/';
                if(await canLaunch(url)){
                  await launch(url,
                  enableJavaScript: true,
                    forceWebView: true,
                    forceSafariVC: true
                  );
                } else throw 'could not launch :/';
              },
              child: Text('Bericht',style: TextStyle(fontWeight: FontWeight.bold),),
            ),
          )
        ],
      ),
    );
  }
}
