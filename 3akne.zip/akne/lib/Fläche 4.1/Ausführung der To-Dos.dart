import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';


class Ausfuehrung extends StatefulWidget {
  String title;

  Ausfuehrung(this.title);

  @override
  _AusfuehrungState createState() => _AusfuehrungState();
}

class _AusfuehrungState extends State<Ausfuehrung> {

  void GL1(String identify) {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          if(identify == 'GL1') {
          return AlertDialog(
              content: Container(
            height: 170,
            child: Stack(children: <Widget>[
              Align(
                  alignment: Alignment(0, 0),
                  child: Text(
                      'Kartoffeln/Reis/Nudeln bilden beim abkühlen resitente Stärke.\n'
                      'Diese sorgt dafür, dass der Blutzuckerspiegel weniger ansteigt'
                      ' und weniger Insulin ausgeschüttet wird.')),
            ]),
          ));}
          if(identify == 'GL2'){
            return AlertDialog(
                content: Container(
                    height: 140,
                    child: Stack(children: <Widget>[
                      Align(
                          alignment: Alignment(0, 0),
                          child: Text(
                            'Ballaststoffe sorgen dafür, dass der Blutzuckerspiegel weniger ansteigt'
                                ' und weniger *Insulin* ausgeschüttet wird.',
                          )),
                    ])));
          }
          if(identify == 'GL3') {
            return AlertDialog(
                content: Container(
                    height: 140,
                    child: Stack(children: <Widget>[
                      Align(
                          alignment: Alignment(0, 0),
                          child: Text(
                            'Die jeweiligen Ersatzprodukte sorgen dafür, dass der Blutzuckerspiegel weniger ansteigt'
                                ' und weniger *Insulin* ausgeschüttet wird.',
                          )),
                    ])));
          }
          if(identify == 'FL') {
            return AlertDialog(
              content: Text('Schweinefleisch enthält besonders viel Arachidonsäure,'
                  ' welche extrem entzündungsfördernd wirken.'),
            );
          }

          if(identify == 'FS1') {
            return Center(
              child: Container(
                height: 300,
                width: 300,
                color: Colors.white,
                child: Stack(children: <Widget>[
                  Align(
                      alignment: Alignment(-0.8, 0),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text(
                              'Omega 3',
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.green,
                                  decorationColor: Colors.green,
                                  decoration: TextDecoration.underline),
                            ),
                            Text(
                                'Leinöl\nLachs\nAlgenöl\nLeinsamen\nWaalnüsse\nHeringe\nTunfisch\nOlivenöl\nOliven\nChiasamen',
                                style: TextStyle(
                                    fontSize: 17,
                                    color: Colors.green,
                                    decoration: TextDecoration.none))
                          ])),
                  Align(
                      alignment: Alignment(0.8, 0),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text('Omega 6',
                                style: TextStyle(
                                    fontSize: 17,
                                    color: Colors.red,
                                    decorationColor: Colors.red,
                                    decoration: TextDecoration.underline)),
                            Text(
                                'Sonnenblumenöl\nParanuss\nSchweineschmalz\nDistelöl\nLeberkäse\nSojabohnen\nGans\nMagarine\nRinderfleisch\nSchweineleber',
                                style: TextStyle(
                                    fontSize: 17,
                                    color: Colors.red,
                                    decoration: TextDecoration.none))
                          ]))
                ]),
              ),
            );
          }
          if(identify == 'FS2') {
            return AlertDialog(
                content: Container(
                    height: 75,
                    child: Stack(children: <Widget>[
                      Align(
                          alignment: Alignment(0, 0),
                          child: Text(
                            'Als Vegatarier kannst du Algenölkapseln verwenden.\nAls Allesesser kannst du Fischölkapseln verwenden.',
                            textAlign: TextAlign.center,
                          )),
                    ])));
          }
          if(identify == 'FS3') {
            return Container(
              height: 300,
              width: 300,
              child: AlertDialog(
                  content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Text('Gesättigte Fettsäuren',
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                                decorationColor: Colors.red,
                                decoration: TextDecoration.underline)),
                        Text(
                            'Palmöl\nButter\nKokosfett\nSpeck\nKokosnuss\nSchweineschmalz\nGänseschmalz\nGebäck und Kekse\nFritiertes\nVerarbeitetes Fleisch',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                                decoration: TextDecoration.none))
                      ])),
            );
          }
          if(identify == 'VA'){
            return AlertDialog(
              content: Container(
                  height: 100,
                  width: 100,
                  color: Colors.white,
                  child: Center(
                      child: Text(
                          '1. Karotten\n2. Kalbsleber\n3. Grühnkohl\n4. Petersilie\n5. Wirsing'))),
            );
          }
          if(identify == 'ZN') {
            return AlertDialog(
              content: Container(
                  height: 100,
                  width: 100,
                  color: Colors.white,
                  child: Center(
                      child: Text(
                          '1. Erdnüsse\n2. Haferflocken\n3. Rindfleisch\n4. Linsen\n5. Emmentaler-Käse'))),
            );
          }
          if(identify == 'MG') {
            return AlertDialog(
              content: Container(
                  height: 100,
                  width: 100,
                  color: Colors.white,
                  child: Center(
                      child: Text(
                          '1. Kürbiskerne\n2. Kakaopulver\n3. Cashewnüsse\n4. Haselnüsse\n5. Sojabohnen'))),
            );
          }
          if(identify == 'VD') {
            return AlertDialog(
              content: Container(
                  height: 100,
                  width: 100,
                  color: Colors.white,
                  child: Center(
                      child: Text(
                          '1. Sonnenstrahlen ;)\n2. Lachs\n3. Eier\n4. Pilze\n5. Makrele'))),
            );
          }
          if(identify == 'SL') {
            return AlertDialog(
              content: Container(
                  height: 100,
                  width: 100,
                  color: Colors.white,
                  child: Center(
                      child: Text(
                          '1. Lachs\n2. Linsen\n3. Brokkoli\n4. Eier\n5. Kohlrabi'))),
            );
          }
          if(identify == 'VC') {
            return AlertDialog(
              content: Container(
                  height: 100,
                  width: 100,
                  color: Colors.white,
                  child: Center(
                      child: Text(
                          '1. Chillischote\n2. Schwarze Johannisbeere\n3. Petersilie\n4. Paprika\n5. Grühnkohl'))),
            );
          }
          if(identify == 'ersatz') {
            return AlertDialog(
              content: Container(
                height: 200,
                child: Stack(
                  children: [
                    Align(
                        alignment: Alignment(-0.85, -0.9), child: Text('Nudeln')),
                    Align(
                        alignment: Alignment(-0.1, -0.9),
                        child: Icon(Icons.arrow_forward)),
                    Align(
                        alignment: Alignment(0.85, -0.9),
                        child: Text('Volkornnudeln')),
                    Align(alignment: Alignment(-0.85, -0.3), child: Text('Reis')),
                    Align(
                        alignment: Alignment(-0.1, -0.3),
                        child: Icon(Icons.arrow_forward)),
                    Align(
                        alignment: Alignment(0.85, -0.3), child: Text('Quinoa')),
                    Align(
                        alignment: Alignment(-0.85, 0.3),
                        child: Text('Weißbrot')),
                    Align(
                        alignment: Alignment(-0.1, 0.3),
                        child: Icon(Icons.arrow_forward)),
                    Align(
                        alignment: Alignment(0.85, 0.3),
                        child: Text('Vollkornbrot')),
                    Align(
                        alignment: Alignment(-0.85, 0.9),
                        child: Text('Kartoffeln')),
                    Align(
                        alignment: Alignment(-0.1, 0.9),
                        child: Icon(Icons.arrow_forward)),
                    Align(
                        alignment: Alignment(0.85, 0.9),
                        child: Text('Süßkartoffeln')),
                  ],
                ),
              ),
            );
          }
          if(identify == 'mahlzeiten') {
            return AlertDialog(
              content: Container(
                height: 100,
                child: Stack(
                  children: [
                    Align(
                      alignment: Alignment(-0.7, -0.9),
                      child: Text(
                        'Beispiel',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Align(
                      alignment: Alignment(0, -0.2),
                      child: RichText(
                        text: TextSpan(children: [
                          TextSpan(
                              text: 'Morgens:',
                              style: TextStyle(
                                  decoration: TextDecoration.underline)),
                          TextSpan(
                              text: 'Angebraterne Pilze mir Ei und Avocadodip')
                        ], style: TextStyle(color: Colors.black)),
                      ),
                    ),
                    Align(
                      alignment: Alignment(0, 0.8),
                      child: RichText(
                        text: TextSpan(children: [
                          TextSpan(
                              text: 'Abends:',
                              style: TextStyle(
                                  decoration: TextDecoration.underline)),
                          TextSpan(text: 'Salat mit Paprika und Waalnüssen')
                        ], style: TextStyle(color: Colors.black)),
                      ),
                    )
                  ],
                ),
              ),
            );
          }
          else return AlertDialog(content: Text('Error'),);
        });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text(widget.title),
            backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
        body: SingleChildScrollView(
          child: Column(children: <Widget>[
            Padding(
                padding: EdgeInsets.all(10),
                child: Text('Was sollst du machen?',
                    style: TextStyle(
                        fontSize: 30,
                        color: Color.fromRGBO(35, 112, 192, 1),
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline))),
            if (widget.title == 'Milchprodukte')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    height: 100,
                    width: 600,
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Aufgabe:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: RichText(
                            text: TextSpan(
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                                children: [
                              TextSpan(
                                  text: '1.',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    backgroundColor: Colors.blue,
                                    color: Colors.white,
                                  )),
                              TextSpan(text: ' Verzichte auf Milchprodukte.'),
                            ])),
                      )
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else if (widget.title == 'Süßigkeiten & süße Getränke')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    height: 100,
                    width: 600,
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Aufgabe:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: RichText(
                            text: TextSpan(
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                                children: [
                              TextSpan(
                                  text: '1.',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    backgroundColor: Colors.blue,
                                    color: Colors.white,
                                  )),
                              TextSpan(
                                  text:
                                      ' Verzichte auf Süßigkeiten & Süßgetränke.'),
                            ])),
                      )
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else if (widget.title == 'Fleisch')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                            'Beachte folgende Punkte, wenn du kein Vegetrarier oder Veganer bist:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8.0),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '1.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(text: ' Esse nur Biofleisch.'),
                              ]))),
                      Padding(
                          padding: EdgeInsets.all(8.0),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '2.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text: ' Verzichte auf Schweinefleisch.'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('FL'),
                          child: Text(
                            'Warum?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '3.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Reduziere deinen Fleischkonsum auf ein Maß, mit dem du leben kannst.'),
                              ]))),
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else if (widget.title == 'glykämische Last')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Aufgaben:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8.0),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '1.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Kartoffeln/Nudeln/Reis nach dem Kochen abkühlen lassen.\n(Danach kannst du sie erneut erhitzen und essen.)'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('GL1'),
                          child: Text(
                            'Warum?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8.0),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '2.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Kohlenhydrate mit vielen Ballaststoffen kombinieren.'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('GL2'),
                          child: Text(
                            'Warum?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '3.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Nudeln -> Vollkornnudeln\nKartoffeln -> Quinoa\nReis -> ungeschälter Reis'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('GL3'),
                          child: Text(
                            'Warum?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else if (widget.title == 'Fette')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Schritte:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '1.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Omega 3 haltige Lebensmittel vermehrt in die Ernährung integrieren.\nOmega 6 haltige Lebensmittel reduzieren.'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('FS1'),
                          child: Text(
                            'Wo enthalten?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '1.2',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Omega 3 supplementieren. (möglicher Zusatz)'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('FS2'),
                          child: Text(
                            'Wie?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '2.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Gesättigte Fettsäuren sollten maximal 1/3'
                                            ' deines gesamten Fettkonsums ausmachen.'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('FS3'),
                          child: Text(
                            'Wo enthalten?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8),
                        child: Text('(Fette sind in den richtigen Mengen sehr wichtig für deine Haut.'
                            ' Mache bitte nicht den Fehler, eine Diät mit wenigen'
                            ' Fetten zu starten.)',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 17),),)
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else if (widget.title == 'Nährstoffbedarf')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Aufgabe:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '1.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Konsumiere mehr Lebensmittel, welche Nährstoffe enthalten, die deine Haut positiv beeinflussen. Zum Beispiel:'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: Column(
                            children: <Widget>[
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    ElevatedButton(
                                      onPressed: () => GL1('VA'),
                                      child: Text(
                                        'Vitamin A',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          primary:
                                              Color.fromRGBO(35, 112, 192, 1)),
                                    ),
                                    ElevatedButton(
                                      onPressed: () => GL1('ZN'),
                                      child: Text(
                                        'Zink',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          primary:
                                              Color.fromRGBO(35, 112, 192, 1)),
                                    ),
                                    ElevatedButton(
                                      onPressed: () => GL1('MG'),
                                      child: Text(
                                        'Magnesium',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          primary:
                                              Color.fromRGBO(35, 112, 192, 1)),
                                    )
                                  ]),
                              Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    ElevatedButton(
                                      onPressed: () => GL1('VD'),
                                      child: Text(
                                        'Vitmin D',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          primary:
                                              Color.fromRGBO(35, 112, 192, 1)),
                                    ),
                                    ElevatedButton(
                                      onPressed: () => GL1('SL'),
                                      child: Text(
                                        'Selen',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          primary:
                                              Color.fromRGBO(35, 112, 192, 1)),
                                    ),
                                    ElevatedButton(
                                      onPressed: () => GL1('VC'),
                                      child: Text(
                                        'Vitamin C',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                          primary:
                                              Color.fromRGBO(35, 112, 192, 1)),
                                    )
                                  ]),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '2.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Überlege, ob es für dich Sinn macht, bestimmte Nährstoffe über Nahrungsergänzungsmittel zu dir zu nehmen'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () async {
                            const url =
                                'https://www.instagram.com/p/CQ3xxTvFkIu/';
                            if (await canLaunch(url)) {
                              await launch(url,
                                  forceWebView: true,
                                  enableJavaScript: true,
                                  forceSafariVC: true);
                            } else {
                              throw 'URL funktioniert nicht';
                            }
                          },
                          child: Text(
                            'Nahrungsergänzungsmittel?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      )
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else if (widget.title == 'Kohlenhydrate')
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    child: Column(children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Aufgabe:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            'Versuche, deine täglich konsumierte Kohlenhydratmenge herabzusetzen.\n'
                            'Fokussiere dich dabei auf kohlenhydratreiche Kost mit im Verhältniss wenigen Ballaststoffen / Vitaminen usw.\n'
                            '\nAchte einfach darauf, dass du folgende Tipps so häufig wie möglich befolgst:',
                            style: TextStyle(fontSize: 17, color: Colors.black),
                            textAlign: TextAlign.center,
                          )),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Tipps:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20)),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '1.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        ' Ersetzte hautunfreundliche Kohlenhydratquellen mit haufreundlicheren Alternativen.'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('ersatz'),
                          child: Text(
                            'Wie?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '2.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        'Konsumiere eine Mahlzeit am Tag mit sehr wenig Kohlenhydraten.'),
                              ]))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          onPressed: () => GL1('mahlzeiten'),
                          child: Text(
                            'Wie?',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                      ),
                      Padding(
                          padding: EdgeInsets.all(8),
                          child: RichText(
                              text: TextSpan(
                                  style: TextStyle(
                                      fontSize: 17, color: Colors.black),
                                  children: [
                                TextSpan(
                                    text: '3.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      backgroundColor:
                                          Color.fromRGBO(35, 112, 192, 1),
                                      color: Colors.white,
                                    )),
                                TextSpan(
                                    text:
                                        'Reduziere die Menge an Fertigprodukten in deiner Ernährung.'),
                              ]))),
                    ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  ))
            else
              Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                    child: Text(
                      'Du hast sicher deine Gründe, diese Aufgabe zu verfolgen!\n;)',
                      style: TextStyle(fontSize: 17, color: Colors.black),
                      textAlign: TextAlign.center,
                    ),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        color: Colors.white),
                  )),
          ]),
        ),
        backgroundColor: Colors.white);
  }
}