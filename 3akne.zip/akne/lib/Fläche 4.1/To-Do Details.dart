import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:akne/Fläche 4.1/Ausführung der To-Dos.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:akne/Fläche 4.1/Fleischberichte.dart';


class NextScreen extends StatefulWidget {
  final bool? done;
  final String title;

  const NextScreen(this.done, this.title);

  @override
  _NextScreenState createState() => _NextScreenState();
}

class _NextScreenState extends State<NextScreen> {
  void AlertA() {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              content: Text(
                'Die Aufgabe des To-Dos 90% der Zeit umsetzten.',
                style: TextStyle(
                    fontSize: 25,
                    fontFamily: 'Robot',
                    color: widget.done! ? Colors.white : Colors.red),
                textAlign: TextAlign.center,
              ),
              backgroundColor: widget.done! ? Colors.blue : Colors.black);
        });
  }

  void AlertB() {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              content: Text(
                'Wie konstant du das To-Do umsetzt, legst du selber fest.',
                style: TextStyle(
                    fontSize: 25,
                    fontFamily: 'Robot',
                    color: widget.done! ? Colors.white : Colors.red),
                textAlign: TextAlign.center,
              ),
              backgroundColor: widget.done! ? Colors.blue : Colors.black);
        });
  }

  void AlertC() {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              content: Text(
                'Du setzt das To-Do die ganze Zeit um, ohne Ausnahmen.',
                style: TextStyle(
                    fontSize: 25,
                    fontFamily: 'Robot',
                    color: widget.done! ? Colors.white : Colors.red),
                textAlign: TextAlign.center,
              ),
              backgroundColor: widget.done! ? Colors.blue : Colors.black);
        });
  }

  void Berichte() {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          return Align(
              alignment: Alignment(0, 0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Text(
                      'Wie kann dir dieses To-Do helfen?',
                      style: TextStyle(
                          color: widget.done! ? Colors.blue : Colors.red,
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          decoration: TextDecoration.none),
                    ),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                          primary: widget.done! ? Colors.blue : Colors.red,
                          onPrimary:
                              widget.done! ? Colors.white : Colors.black),
                      onPressed: () async {
                        if (widget.title == 'Milchprodukte') {
                          const url =
                              'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4884775/#:~:text=The%20authors%20found%20that%20acne%20was%20positively%20associated,Estrogen%20is%20a%20hormone%20that%20may%20reduce%20acne.';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Süßigkeiten & süße Getränke') {
                          const url =
                              'https://pubmed.ncbi.nlm.nih.gov/21034984/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if(widget.title == 'Fleisch') {
                          Navigator.push<Widget>(context,
                              MaterialPageRoute<Widget>(
                              builder: (BuildContext context) => FleischBerichte()));
                        }
                        if (widget.title == 'glykämische Last') {
                          const url =
                              'https://pubmed.ncbi.nlm.nih.gov/17616769/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Fette') {
                          const url =
                              'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4507494/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Nährstoffbedarf') {
                          const url =
                              'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8226785/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Kohlenhydrate') {
                          const url =
                              'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8226785/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                      },
                      label: Text(
                        'medizinischer Bericht',
                        style: TextStyle(fontFamily: 'Robot'),
                      ),
                      icon: Icon(
                        Icons.medical_services_outlined,
                        color: widget.done! ? Colors.white : Colors.black,
                      ),
                    ),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                          primary: widget.done! ? Colors.blue : Colors.red,
                          onPrimary:
                              widget.done! ? Colors.white : Colors.black),
                      onPressed: () async {
                        if (widget.title == 'Milchprodukte') {
                          const url =
                              'https://www.instagram.com/p/CZuTAZhMbHe/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Süßigkeiten & süße Getränke') {
                          const url =
                              'https://www.instagram.com/p/CZcaRtxMSRA/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if(widget.title == 'Fleisch') {
                          const url = 'https://www.instagram.com/p/CPd1ZZjlsZ9/';

                          if(await canLaunch(url)) {
                            await launch(url,
                                forceSafariVC: true,
                                forceWebView: true,
                                enableJavaScript: true
                            );
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'glykämische Last') {
                          const url =
                              'https://www.acne.org/do-sugary-foods-and-drinks-cause-acne.html';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Fette') {
                          const url =
                              'https://www.instagram.com/p/Cb-bj8ss5xa/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Nährstoffbedarf') {
                          const url =
                              'https://www.aponet.de/artikel/fuenf-naehrstoffe-fuer-die-haut-24836';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                        if (widget.title == 'Kohlenhydrate') {
                          const url =
                              'https://www.instagram.com/p/CcQpfnls8ge/';
                          if (await canLaunch(url)) {
                            await launch(url,
                                forceWebView: true,
                                enableJavaScript: true,
                                forceSafariVC: true);
                          } else {
                            throw 'Could not launch :(';
                          }
                        }
                      },
                      label: Text(
                        'leicht verständliche Darstellung',
                        style: TextStyle(fontFamily: 'Robot'),
                      ),
                      icon: Icon(
                        Icons.lightbulb_outline,
                        color: widget.done! ? Colors.white : Colors.black,
                      ),
                    ),
                    Text('(In manchen Berichten, wird das gesuchte Thema in einem '
                        'bestimmten Absatz behandelt.)', textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w300, fontSize: 17,
                    color: widget.done! ? Colors.blue : Colors.red,
                    decoration: TextDecoration.none
                    ),
                    )
                  ],
                ),
                height: 200,
                width: 350,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: widget.done! ? Colors.white : Colors.black),
              ));
        });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.title == 'Beispiel-To-Do') {
      return Scaffold(
        appBar: AppBar(
          title: Text('Worauf wartest du?',
              style: TextStyle(decoration: TextDecoration.underline)),
          backgroundColor: Color.fromRGBO(35, 112, 192, 1),
        ),
        body: Center(
            child: Text(
          'Fang an, tägliche Aufgaben festzulegen, die du für wichtig hälst.',
          style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Color.fromRGBO(238, 105, 38, 1)),
          textAlign: TextAlign.center,
        )),
        backgroundColor: Colors.white,
      );
    } else
      return Scaffold(
          backgroundColor: widget.done! ? Colors.green : Colors.red,
          appBar: AppBar(
            title: Text(widget.title),
            backgroundColor: Colors.transparent,
          ),
          body: Padding(
              padding: EdgeInsets.all(10),
              child: Column(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                      child: TextButton(
                          onPressed: () => Navigator.push<Widget>(
                              context,
                              MaterialPageRoute<Widget>(
                                  builder: (BuildContext context) =>
                                      Ausfuehrung(widget.title))),
                          style: TextButton.styleFrom(
                            backgroundColor: Colors.white10
                          ),
                          child: Text(
                            'Was musst du machen?',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: widget.done!
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline),
                          ))),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    'Mögliche Optionen:',
                    style: TextStyle(
                        color: widget.done! ? Colors.white : Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: widget.done! ? Colors.blue : Colors.black),
                        onPressed: () => AlertA(),
                        child: Text(
                          'A',
                          style: TextStyle(
                              color: widget.done! ? Colors.white : Colors.red),
                        )),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: widget.done! ? Colors.blue : Colors.black),
                        onPressed: () => AlertB(),
                        child: Text(
                          'B',
                          style: TextStyle(
                              color: widget.done! ? Colors.white : Colors.red),
                        )),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: widget.done! ? Colors.blue : Colors.black),
                        onPressed: () => AlertC(),
                        child: Text(
                          'C',
                          style: TextStyle(
                              color: widget.done! ? Colors.white : Colors.red),
                        ))
                  ],
                ),
                Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 8, vertical: 20),
                  child: Container(
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          Icon(
                            widget.done! ? Icons.done : Icons.access_alarm,
                            color: widget.done! ? Colors.white : Colors.black,
                            size: 100,
                          ),
                          Text(
                            widget.done!
                                ? 'Super! Du arbeitest daran, dein Hautbild zu verbessern!'
                                : 'Dieses To-Do musst du noch erledigen!',
                            style: TextStyle(
                                fontSize: 20,
                                color:
                                    widget.done! ? Colors.white : Colors.black,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          )
                        ]),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5,
                            color: widget.done! ? Colors.white : Colors.black)),
                    width: 400,
                    height: 270,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 20),
                  child: Container(
                      child: TextButton(
                          onPressed: () => Berichte(),
                          child: Text(
                            'Wie kann dir diese To-Do helfen?',
                            style: TextStyle(
                                color: widget.done!
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 18,
                                decoration: TextDecoration.underline),
                            textAlign: TextAlign.center,
                          ))),
                ),
              ])));
  }
}