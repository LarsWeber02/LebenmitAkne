import 'package:akne/Fl%C3%A4che%202/Stufenzeit.dart';
import 'package:akne/Fl%C3%A4che%202/Überblick.dart';
import 'package:akne/Fläche 2/Stufenzusatz.dart';
import 'package:akne/etc/Database.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:akne/Fl%C3%A4che%202/Home.dart';
import 'package:akne/Fläche 2/Kalender.dart';
import 'package:akne/Fläche 1/Introduction.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(home: Introduction()));
}

class Uebersicht extends StatefulWidget {
  @override
  _UebersichtState createState() => _UebersichtState();
}

class _UebersichtState extends State<Uebersicht> {
  User? user;
  late DatabaseService database;

  Future<void> connect() async {
    final FirebaseAuth auth = FirebaseAuth.instance;
    UserCredential result = await auth.signInAnonymously();
    user = result.user;
    database = DatabaseService(user!.uid);

    if (!(await database.checkIfUserExists())) return await database.setUser();
  }

  void time() {
    showDialog<AlertDialog>(
      context: context,
      builder: (BuildContext context) {
        return TimeSet();
      },
      barrierDismissible: false,
    );
  }

  Future stufenEnde() async {
    if (await database.endTime() == true) {
      return showDialog(
          context: context,
          builder: (BuildContext context) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  color: Colors.white,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Die Zeitspanne inder du die Stufe ausführen wolltest, ist um!',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 20, color: Color.fromRGBO(35, 112, 192, 1), decoration: TextDecoration.none),
                        ),
                      ),
                      Text(
                        'Wie willst du weiter vorgehen?',
                        style: TextStyle(fontSize: 20, color: Color.fromRGBO(35, 112, 192, 1), decoration: TextDecoration.none),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 25),
                        child: TextButton(
                          onPressed: () {
                            time();
                            },
                          child: Text('aktuelle Stufe beibehalten'),
                          style: TextButton.styleFrom(
                              padding: EdgeInsets.all(10),
                              primary: Colors.white,
                              backgroundColor: Colors.green
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextButton(
                            onPressed: () {
                              database.deleteTodo();
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content:
                                    Text('Schaue dir die Stufen nochmal an ;)',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(color: Colors.white),),
                                    backgroundColor: Color.fromRGBO(35, 112, 192, 1),
                                  ));
                            },
                            child: Text('eine neue Stufe auswählen'),
                            style: TextButton.styleFrom(
                                padding: EdgeInsets.all(10),
                                primary: Colors.white,
                                backgroundColor: Colors.green)
                        ),
                      )
                    ],
                  ),
                ),
              ),
                );
          });
    } else
      print('Stufe läuft');
  }

  final screens = [Startseite(), Stufenzusatz(), Kalender(), Home()];
  int _currentIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
    Future.delayed(Duration(seconds: 2), () async {
      if (await database.checkTime() == true) {
        return await database.allFalse();
      } else
        print('Still time left');
    });
    Future.delayed(Duration(milliseconds: 1), () async {
      return stufenEnde();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: IndexedStack(index: _currentIndex, children: screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color.fromRGBO(35, 112, 192, 1),
        unselectedItemColor: Colors.white60,
        selectedItemColor: Colors.white,
        iconSize: 30,
        selectedFontSize: 18,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.search),
              label: 'Search',
              backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
          BottomNavigationBarItem(
              icon: Icon(Icons.add),
              label: 'Zusatz',
              backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today),
              label: 'Kalender',
              backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
              backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
        ],
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }
}
