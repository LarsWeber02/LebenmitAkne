import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  String userID;

  DatabaseService(this.userID);

  final CollectionReference users =
      FirebaseFirestore.instance.collection('users');

  Future allFalse() async {
    Future.delayed(Duration(seconds: 0), () async {
      return await users.doc(userID).get().then((DocumentSnapshot doc) {
        var updateMap = new Map();
        var toDos = doc['Level'];
        for (var item in toDos.keys) {
          updateMap[item] = false;
        }
        doc.reference.update({'Level': updateMap});
      });
    });
    Future.delayed(Duration(seconds: 2), () async {
      return await users.doc(userID).set({
        'Stufenzeit': {
          'Resetdatum': DateTime.utc(
              2022, 1, (DateTime.now().add(Duration(days: 1))).day, 2)
        }
      }, SetOptions(merge: true));
    });
  }

  Future<bool> checkTime() async {
    final now = DateTime.now();
    final doc = await users.doc(userID).get();
    final stufenzeit = (doc.data() as Map<String, dynamic>)['Stufenzeit']
        as Map<String, dynamic>;
    final storedData =
        ((stufenzeit as Map<String, dynamic>)['Resetdatum'] as Timestamp)
            .toDate();
    print(storedData);
    return now.compareTo(storedData) > 0;
  }

  Future<bool> endTime() async {
    final DateTime now = DateTime.now();
    final doc = await users.doc(userID).get();
    final store = (doc.data() as Map<String, dynamic>)['Stufenzeit']
        as Map<String, dynamic>;
    final endTime =
        ((store as Map<String, dynamic>)['Enddatum'] as Timestamp).toDate();
    return now.compareTo(endTime) > 0;
  }

  Future setUser() async {
    Future.delayed(Duration(seconds: 0), () async {
      return await users.doc(userID).set({'Level': {}});
    });
    Future.delayed(Duration(seconds: 1), () async {
      return await users.doc(userID).update({'Level': FieldValue.delete()});
    });
  }

  Future setTodo(String level, bool value) async {
    return await users.doc(userID).set({
      'Level': {level: value}
    }, SetOptions(merge: true));
  }

  Future setTodoS(String level, bool value) async {
    return await users.doc(userID).set({
      'Level': {level: value}
    }, SetOptions(merge: true));
  }

  Future setTodoS1() async {
    return await users.doc(userID).set({
      'Level': {'Beispiel-To-Do': false}
    });
  }

  Future setTodoS2(String key) async {
    return await users.doc(userID).set({
      'Level': {key: false}
    }, SetOptions(merge: true));
  }

  Future setTodo1() async {
    return await users.doc(userID).set({
      'Level': {'Süßigkeiten & süße Getränke': false}
    });
  }

  Future setTodo2() async {
    return await users.doc(userID).set({
      'Level': {'Milchprodukte': false, 'Süßigkeiten & süße Getränke': false}
    });
  }

  Future setTodo3() async {
    return await users.doc(userID).set({
      'Level': {
        'Milchprodukte': false,
        'Süßigkeiten & süße Getränke': false,
        'Fleisch': false,
        'glykämische Last': false
      }
    });
  }

  Future setTodo4() async {
    return await users.doc(userID).set({
      'Level': {
        'Milchprodukte': false,
        'Süßigkeiten & süße Getränke': false,
        'Fleisch': false,
        'glykämische Last': false,
        'Fette': false
      }
    });
  }

  Future setTodo5() async {
    return await users.doc(userID).set({
      'Level': {
        'Milchprodukte': false,
        'Süßigkeiten & süße Getränke': false,
        'Fleisch': false,
        'glykämische Last': false,
        'Fette': false,
        'Nährstoffbedarf': false
      }
    });
  }

  Future setTodo6() async {
    return await users.doc(userID).set({
      'Level': {
        'Milchprodukte': false,
        'Süßigkeiten & süße Getränke': false,
        'Fleisch': false,
        'glykämische Last': false,
        'Fette': false,
        'Nährstoffbedarf': false,
        'Kohlenhydrate': false
      }
    });
  }

  Future deleteTodo() async {
    Future.delayed(Duration(seconds: 0), () async {
      return await users.doc(userID).set({
        'Level': FieldValue.delete(),
      }, SetOptions(merge: true));
    });
    Future.delayed(Duration(seconds: 0), () async {
      return await users
          .doc(userID)
          .set({'Stufenzeit': FieldValue.delete()}, SetOptions(merge: true));
    });
  }

  Future deleteTile(String key) async {
    return await users.doc(userID).set({
      'Level': {key: FieldValue.delete()}
    }, SetOptions(merge: true));
  }

  Future checkIfUserExists() async {
    if ((await users.doc(userID).get()).exists) {
      return true;
    } else {
      return false;
    }
  }

  Stream<DocumentSnapshot> getTodos() {
    return users.doc(userID).snapshots();
  }
}

class KalenderService {
  String userID;
  KalenderService(this.userID);

  final CollectionReference users =
      FirebaseFirestore.instance.collection('users');

  Future Stufenende(DateTime date1, DateTime date2) async {
    return await users.doc(userID).set({
      'Stufenzeit': {
        'Startdatum': date1,
        'Enddatum': date2,
        'Resetdatum': date1.add(Duration(days: 1))
      }
    }, SetOptions(merge: true));
  }

  Stream<DocumentSnapshot> getTime() {
    return users.doc(userID).snapshots();
  }
}
