import 'package:akne/etc/Database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';


class LoginPage extends StatefulWidget {
  final Function(User) onSignInAno;
  const LoginPage({Key? key, required this.onSignInAno}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  User? user;
  late DatabaseService database;

  final CollectionReference users =
  FirebaseFirestore.instance.collection('users');

  loginAno() async{
    UserCredential userCredential = await FirebaseAuth.instance.signInAnonymously();
    widget.onSignInAno(userCredential.user!);
  }

  Future crDoc() async{
    final FirebaseAuth auth = FirebaseAuth.instance;
    user = auth.currentUser;
    database = DatabaseService(user!.uid);
    return database.setUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(title: Center(child: Text('Login Page'))),
    body: Center(
      child: ElevatedButton(
      onPressed: () {
        loginAno();
        crDoc();
        },
  child: Text('Ich bin neu hier')
      ),
    ),
    );
  }
}
