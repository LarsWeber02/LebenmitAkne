import 'package:akne/Fl%C3%A4che%204.1/To-Do%20Details.dart';
import 'package:flutter/material.dart';

import '../Fläche 2/Home.dart';

class ToDo1 extends StatefulWidget {
  final String Stufe;

const ToDo1(this.Stufe);
  @override
  _ToDo1State createState() => _ToDo1State();
}

class _ToDo1State extends State<ToDo1> {
  late Map<String, bool> products;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

      if(widget.Stufe == 'Süßigkeiten & süße Getränke')
        products = {  'Süßigkeiten & süße Getränke': true};
      if(widget.Stufe == 'Milchprodukte')
      products = {'Süßigkeiten & süße Getränke': true,
        'Milchprodukte': true};
    if(widget.Stufe == 'Glykämische Last')
      products = {'Süßigkeiten & süße Getränke': true,
        'Milchprodukte': true,
        'Fleisch':true,
        'glykämische Last': true,};
    if(widget.Stufe == 'Fette')
      products = {'Süßigkeiten & süße Getränke': true,
        'Milchprodukte': true,
        'Fleisch':true,
        'glykämische Last': true,
        'Fette': true,};
    if(widget.Stufe == 'Nährstoffbedarf')
      products = {'Süßigkeiten & süße Getränke': true,
        'Milchprodukte': true,
        'Fleisch':true,
        'glykämische Last': true,
        'Fette': true,
        'Nährstoffbedarf': true};
      if(widget.Stufe == 'Kohlenhydrate')
      products = {'Süßigkeiten & süße Getränke': true,
        'Milchprodukte': true,
        'Fleisch':true,
        'glykämische Last': true,
        'Fette': true,
        'Nährstoffbedarf': true,
        'Kohlenhydrate': true};
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(
              child: Text(
            widget.Stufe,
            style: TextStyle(
                fontStyle: FontStyle.italic,
                decoration: TextDecoration.underline),
          )),
          backgroundColor: Color.fromRGBO(35, 112, 192, 1),
        ),
        body: ListView.separated(
            separatorBuilder: (BuildContext context, int index) {

              return SizedBox(
                height: 10,
              );
            },
            padding: EdgeInsets.all(10),
            itemCount: products.length,
            itemBuilder: (BuildContext, i) {
              String key = products.keys.elementAt(i);
              return ToDoItem(key,
                  products[key]!
              );
            }));
  }
}


class ToDoS extends StatefulWidget {
  @override
  _ToDoSState createState() => _ToDoSState();
}

class _ToDoSState extends State<ToDoS> {
  Map<String, bool> products = {};

  void toggleDone(String key) {
    setState(() {
      products.update(key, (bool done) => !done);
    });
  }

  void addItem(key) {
    setState(() {
      products[key] = false;
    });
    Navigator.pop(context);
  }

  void newEntry() {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          return addItemDialog(addItem);
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
            child: Text(
          'Selbstentworfene Stufe',
          style: TextStyle(
              fontStyle: FontStyle.italic,
              decoration: TextDecoration.underline),
        )),
        backgroundColor: Color.fromRGBO(35, 112, 192, 1),
      ),
      body: ListView.separated(
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox(
              height: 10,
            );
          },
          padding: EdgeInsets.all(10),
          itemCount: products.length,
          itemBuilder: (BuildContext, i) {
            String key = products.keys.elementAt(i);
            return ToDoItem(
              key,
              products[key]!,
            );
          }),
      floatingActionButton: FloatingActionButton(
        onPressed: newEntry,
        backgroundColor: Color.fromRGBO(35, 112, 192, 1),
        child: Icon(Icons.add),
      ),
    );
  }
}


class ToDoItem extends StatelessWidget {
  final String title;
  final bool done;

  const ToDoItem(this.title, this.done);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            border: Border.all(
                width: 5,
                color: Color.fromRGBO(238, 105, 38, 1)),
            borderRadius: BorderRadius.circular(10)),
        child: ListTile(
          contentPadding: EdgeInsets.symmetric(vertical: 20),
          title: Center(
              child: Text(
            title,
            style: TextStyle(
                color: Color.fromRGBO(238, 105, 38, 1),
                fontWeight: FontWeight.bold),
          )),
          onTap: () {
            Navigator.push<Widget>(
              context,
              MaterialPageRoute<Widget>(
                  builder: (BuildContext context) => NextScreen(done, title)),
            );
          },
          tileColor: Colors.white,
        ));
  }
}
