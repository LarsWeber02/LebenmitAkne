import 'package:akne/etc/Database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class StufenzusatzInfo extends StatefulWidget {
  final String title;

  const StufenzusatzInfo(this.title);
  @override
  _StufenzusatzInfoState createState() => _StufenzusatzInfoState();
}

class _StufenzusatzInfoState extends State<StufenzusatzInfo> {
  User? user;
  late DatabaseService database;
  final CollectionReference users =
      FirebaseFirestore.instance.collection('users');

  Future<void> connect() async {
    user = FirebaseAuth.instance.currentUser;
    database = DatabaseService(user!.uid);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: TextStyle(
              color: Colors.white, decoration: TextDecoration.underline),
        ),
        backgroundColor: Color.fromRGBO(35, 112, 192, 1),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Was musst du machen?', style: TextStyle(fontSize: 25)),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.arrow_circle_down,
                size: 100, color: Color.fromRGBO(238, 105, 38, 1)),
          ),
          if (widget.title == 'Meditieren')
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('Meditiere täglich', style: TextStyle(fontSize: 25)),
            )
          else if (widget.title == 'Sport')
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                  'Betreibe mindestens 150–300 Minuten pro Woche Sport mit mittlerer Intensität\n'
                  ' und 75–150 Minuten pro Woche mit leicht erhöhter Intensität.',
                  style: TextStyle(fontSize: 25),
                  textAlign: TextAlign.center),
            )
          else if (widget.title == 'Intervallfasten')
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                  'Du darfst 8 Stunden am Tag etwas essen und 16 Stunden fasten.\n'
                  '(Erlaubt, während den 16 Stunden ist Wasser, ungesüßten Kaffe und Tee.)',
                  style: TextStyle(fontSize: 25),
                  textAlign: TextAlign.center),
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(
                      width: 5, color: Color.fromRGBO(238, 105, 38, 1))),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    if (widget.title == 'Meditieren')
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Meditation hilft bei\nder Stressbewältigung\nund kann somit\nStresspickeln entgegenwirken.',
                          style: TextStyle(fontSize: 17),
                          textAlign: TextAlign.center,
                        ),
                      )
                    else if (widget.title == 'Intervallfasten')
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Deutlich weniger\nInsulin wird ausgeschüttet!',
                          style: TextStyle(fontSize: 17),
                          textAlign: TextAlign.center,
                        ),
                      )
                    else if (widget.title == 'Sport')
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Sport hilft bei\nder Stressbewältigung\nund kann somit\nStresspickeln entgegenwirken.',
                          style: TextStyle(fontSize: 17),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    if (widget.title == 'Meditieren')
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                          width: 100,
                          height: 100,
                          child: Image(
                            image: NetworkImage(
                                'https://cdn.pixabay.com/photo/2016/11/22/23/29/meditate-1851165_960_720.jpg'),
                          ),
                        ),
                      )
                    else if (widget.title == 'Intervallfasten')
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                          height: 100,
                          width: 100,
                          child: Image(
                            image: NetworkImage(
                                'https://images.pexels.com/photos/1198264/pexels-photo-1198264.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940'),
                          ),
                        ),
                      )
                    else if (widget.title == 'Sport')
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                          height: 100,
                          width: 100,
                          child: Image(
                            image: NetworkImage(
                                'https://cdn.pixabay.com/photo/2017/05/25/15/08/jogging-2343558_960_720.jpg'),
                          ),
                        ),
                      )
                  ]),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(30.0),
            child: FloatingActionButton(
              onPressed: () {
                database.setTodo(widget.title, false);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(
                    'Erfolgreich zu deinen Todos hinzugefügt ;)',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white),
                  ),
                  backgroundColor: Color.fromRGBO(35, 112, 192, 1),
                ));
              },
              child: Icon(Icons.add, color: Colors.white),
              backgroundColor: Colors.green,
              splashColor: Colors.green,
              elevation: 20,
            ),
          )
        ],
      ),
    );
  }
}
