import 'package:akne/Fl%C3%A4che%202/Datenschutz.dart';
import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:akne/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:akne/etc/Database.dart';

class Introduction extends StatefulWidget {
  const Introduction({Key? key}) : super(key: key);

  @override
  State<Introduction> createState() => _IntroductionState();
}

class _IntroductionState extends State<Introduction> {
  User? user;
  late DatabaseService database;

  Future<void> connect() async {
    final FirebaseAuth auth = FirebaseAuth.instance;
    UserCredential result = await auth.signInAnonymously();
    user = result.user;
    database = DatabaseService(user!.uid);

    if (!(await database.checkIfUserExists())) return await database.setUser();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: IntroductionScreen(
        pages: [
          PageViewModel(
              title: 'Wobei hilft dir diese App?',
              body: "Sie zeigt dir eine klare Vorgehensweise, wie du dein Leben"
                  " hautfreundlicher gestalten kannst...",
              image: buildImage2('assets/images/Intro.png'),
            decoration: getPageDecoration()
          ),
          PageViewModel(
              title: 'Wobei hilft dir diese App?',
              body: "...oder hilft dir bei der Umsetzung deines Plans"
                  " wenn du genau weißt, was du machen möchtest, um ein besseres"
                  " Hautbild zu erreichen.",
              image: buildImage('assets/images/Intro.png'),
              decoration: getPageDecoration()
          ),
          PageViewModel(
              titleWidget: buildImage2('assets/images/Startseite-1.png'),
              body: "Die App bietet dir unterschiedliche Stufen der hautfreundlichen"
                  " Ernährung.\nSchau dir alle ganz genau an.",
              decoration: getPageDecoration()
          ),
          PageViewModel(
              titleWidget: buildImage2('assets/images/Home.png'),
              body: "In der Homeansicht kannst du, wenn du alle Stufen angeschaut hast,"
                  " eine passende auswählen.",
              decoration: getPageDecoration()
          ),
          PageViewModel(
              titleWidget: buildImage2('assets/images/Home(Zeit).png'),
              body: 'Die in der Stufe enthaltenen "Aufgaben" werden dir für einen,'
                  ' von dir festgelegten Zeitraum täglich zum abhaken angeboten.',
              decoration: getPageDecoration()
          ),
          PageViewModel(
              titleWidget: buildImage2('assets/images/Startseite-Stufe.png'),
              body: "So behältst du den Überblick über die Dinge, die du dir vorgenommen hast.",
              decoration: getPageDecoration()
          ),
          PageViewModel(
              titleWidget: buildImage('assets/images/Sartseite-2.png'),
              body: 'Eine genauere Erklärung zu weiteren Featers der App kannst du'
                  ' dir auf der Startseite unter "Wie funktioniert die App? anschauen.',
              footer: TextButton(
                child: Text('Datenschutzerkärung'),
                style: TextButton.styleFrom(
                  primary: Colors.white,
                  backgroundColor: Color.fromRGBO(35, 112, 192, 1)
                ),
                onPressed: () => Navigator.push(context, MaterialPageRoute(
                  builder: (BuildContext context) => Datenschutz()
                )),),
              decoration: getPageDecoration()
          ),
        ],
        done: Text("Let's go!"),
        onDone: () => goHomepage(context),
        showSkipButton: true,
        skip: Text('Skip', style: TextStyle(color: Colors.black),),
        next: Icon(Icons.arrow_forward),
        dotsFlex: 0,
      ),
    );
  }
}


void goHomepage(context) => Navigator.of(context).pushReplacement(
  MaterialPageRoute(builder: (_) => Uebersicht())
);

Widget buildImage(String path) => Center(child: Image.asset(path, width: 300));
Widget buildImage2(String path) => Center(child: Image.asset(path, width: 500, height: 500,));

PageDecoration getPageDecoration() => PageDecoration(
  titleTextStyle: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
  bodyTextStyle: TextStyle(fontSize: 18),
  bodyPadding: EdgeInsets.all(5),
    imagePadding: EdgeInsets.all(30),
);


