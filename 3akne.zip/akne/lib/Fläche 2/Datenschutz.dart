import 'dart:ui';

import 'package:flutter/material.dart';


class Datenschutz extends StatelessWidget {
  const Datenschutz({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Center(child: Text('Datenschutzerklärung')),
        backgroundColor: Color.fromRGBO(35, 112, 192, 1),),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Wer ist der Appanbieter?', style:
              TextStyle(
                  decoration: TextDecoration.underline,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Color.fromRGBO(35, 112, 192, 1)),),
          ),
          Text('Lars Weber', style: TextStyle(fontSize: 16),),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Text('Kontakt: die.akne.app@gmail.com',
              style: TextStyle(fontSize: 16)),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Welche Daten bezieht die App?', style:
            TextStyle(
                decoration: TextDecoration.underline,
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Color.fromRGBO(35, 112, 192, 1)),),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Die täglich festgelegten Aufgaben und die ausgewählte'
                ' Durchführungszeitspanne werden unter einer für den User zufällig'
                ' generierten UserID gespeichert.\n'
                ' Die Daten werden so lange gespeichert,'
                ' bis der Benutzer das „Lösch-Icon“ über seinen ausgewählten'
                ' To-Dos in der rechten Ecke betätigt.\n'
                ' Das Nutzerverhalten wird über Google-Analytics ausgewertet.\n'
                ' Es werden keine Daten an dritte weitergegeben.',
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Haftung',
                style: TextStyle(
                decoration: TextDecoration.underline,
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Color.fromRGBO(35, 112, 192, 1))),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Denke bitte daran, dass ich kein Arzt bin. All das Wissen,'
                ' welches ich dir über diese App vermittle, habe ich durch das'
                ' Lesen medizinischer Berichte erworben.\n'
                ' Die Quellen sind dabei sehr hochwertig und vertrauenswürdig.'
                ' Dennoch kann es sein, dass ich Dinge falsch interpretiert habe.\n'
                ' Die Stufen beinhalten also keine 100 %ige Garantie auf Besserung'
                ' deiner Haut.\n'
                ' Schließlich bin ich nur ein Sportstudent, der mit dieser App'
                ' versucht zu helfen.',
              textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),),
          )
        ],
      ),
    );
  }
}
