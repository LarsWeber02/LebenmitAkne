import 'package:akne/Fl%C3%A4che%203.1/Stufenzusatzinfo.dart';
import 'package:akne/etc/Database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


class Stufenzusatz extends StatefulWidget {
  @override
  _StufenzusatzState createState() => _StufenzusatzState();
}

class _StufenzusatzState extends State<Stufenzusatz> {
  final List<String> Zusatz = ['Intervallfasten', 'Sport', 'Meditieren'];
  late DatabaseService database;
  User? user;

  Future connect() async {
    final auth = FirebaseAuth.instance;
    user = auth.currentUser;
    database = DatabaseService(user!.uid);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: database.getTodos(),
      builder: (context, AsyncSnapshot snapshot) {
        if (snapshot.hasData) {
          if (snapshot.data.data()['Level'] == null) {
            return Scaffold(
                appBar: AppBar(
                  title: Center(
                    child: Text(
                      'Stufenzusatz',
                      style: TextStyle(
                          fontSize: 30,
                          color: Colors.white,
                          decoration: TextDecoration.underline),
                    ),
                  ),
                  backgroundColor: Color.fromRGBO(35, 112, 192, 1),
                ),
                body: Center(
                    child: Container(
                  height: 200,
                  width: 300,
                  decoration: BoxDecoration(
                      border: Border.all(
                          width: 8, color: Color.fromRGBO(238, 105, 38, 1))),
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Center(
                        child: Text(
                      'Wähle zuerst eine Stufe aus, bevor du bestimmt Stufenzusätze hinzufügst.',
                      style:
                          TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    )),
                  ),
                )));
          } else {
            return Scaffold(
                appBar: AppBar(
                  title: Center(
                      child: Text(
                    'Stufenzusätze',
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.white,
                        decoration: TextDecoration.underline),
                  )),
                  backgroundColor: Color.fromRGBO(35, 112, 192, 1),
                ),
                body: SingleChildScrollView(child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(0.1),
                      child: Text(
                        'Du willst zu deiner aktuellen Stufe eine Aufgabe hinzufügen?\n',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                            fontSize: 22,
                            color: Color.fromRGBO(35, 112, 192, 1)),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(0.1),
                      child: Text(
                          '1. Schau dir meine Vorschläge genauer an, indem du auf sie klickst.\n2. Oder du erstellst dir deinen eigenen Zusatz.',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(35, 112, 192, 1))),
                    ),
                    Padding(
                        padding:
                            EdgeInsets.symmetric(vertical: 15, horizontal: 15,),
                        child: Container(
                          width: 500,
                          height: 350,
                          color: Colors.white,
                          child: ListView.separated(
                              separatorBuilder:
                                  (BuildContext context, int i) {
                                return SizedBox(height: 15);
                              },
                              itemCount: Zusatz.length,
                              itemBuilder: (BuildContext, i) {
                                return Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        width: 5,
                                        color:
                                            Color.fromRGBO(238, 105, 38, 1),
                                      ),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: ListTile(
                                    contentPadding:
                                        EdgeInsets.symmetric(vertical: 20),
                                    leading: Icon(
                                      Icons.add,
                                      color: Colors.green,
                                      size: 60,
                                    ),
                                    title: Text(
                                      Zusatz[i],
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 25,
                                          color: Color.fromRGBO(
                                              35, 112, 192, 1)),
                                    ),
                                    trailing: Column(children: <Widget>[
                                      if (Zusatz[i] == 'Intervallfasten')
                                        Expanded(
                                            child: Container(
                                          child: Image(
                                              image: NetworkImage(
                                                  'https://images.pexels.com/photos/1198264/pexels-photo-1198264.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940')),
                                          decoration: BoxDecoration(
                                              border: Border(
                                                  right: BorderSide(
                                                      width: 10,
                                                      color: Colors.white))),
                                        ))
                                      else if (Zusatz[i] == 'Sport')
                                        Expanded(
                                            child: Container(
                                                child: Image(
                                                    image: NetworkImage(
                                                        'https://cdn.pixabay.com/photo/2017/05/25/15/08/jogging-2343558_960_720.jpg')),
                                                decoration: BoxDecoration(
                                                    border: Border(
                                                        right: BorderSide(
                                                            width: 10,
                                                            color: Colors
                                                                .white)))))
                                      else if (Zusatz[i] == 'Meditieren')
                                        Expanded(
                                            child: Container(
                                                child: Image(
                                                    image: NetworkImage(
                                                        'https://cdn.pixabay.com/photo/2016/11/22/23/29/meditate-1851165_960_720.jpg')),
                                                decoration: BoxDecoration(
                                                    border: Border(
                                                        right: BorderSide(
                                                            width: 10,
                                                            color: Colors
                                                                .white)))))
                                    ]),
                                    onTap: () {
                                      Navigator.push<Widget>(
                                        context,
                                        MaterialPageRoute<Widget>(
                                            builder: (context) =>
                                                StufenzusatzInfo(Zusatz[i])),
                                      );
                                    },
                                  ),
                                );
                              }),
                        ))
                  ],
                )),
                backgroundColor: Colors.white);
          }
        }
        return Center(child: CircularProgressIndicator());
      },
    );
  }
}


