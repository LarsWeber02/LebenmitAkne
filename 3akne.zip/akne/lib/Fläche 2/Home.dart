import 'dart:async';
import 'package:akne/Fl%C3%A4che%204.1/To-Do%20Details.dart';
import 'package:akne/etc/Database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'Stufenzeit.dart';


class Home extends StatefulWidget {

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  User? user;
  late DatabaseService database;

  Future<void> connect() async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    user = _auth.currentUser;
    database = DatabaseService(user!.uid);
  }

  Map<String, bool> levels = {
    'Level 1': false,
    'Level 2': false,
    'Level 3': false,
    'Level 4': false,
    'Level 5': false,
    'Level 6': false,
    'Level S': false
  };

  void addItem(key) {
    database.setTodoS2(key);
    Navigator.pop(context);
  }

  void newEntry() {
    showDialog<AlertDialog>(
        context: context,
        builder: (BuildContext context) {
          return addItemDialog(addItem);
        });
  }

  void Time() {
    showDialog<AlertDialog>(
      context: context,
      builder: (BuildContext context) {
        return TimeSet();
      },
      barrierDismissible: false,
    );
  }

  void toggleDone(String key) {
    setState(() {
      levels.update(key, (bool value) => !value);
    });
  }

  void toggleDone2(String key, bool value) {
    database.setTodo(key, !value);
  }

  void toggleDoneS(String key, bool value) {
    database.setTodoS(key, !value);
  }

  void deleteTile(String key) {
    database.deleteTile(key);
  }

  void select(key) {
    if (key == 'Level S') {
      database.setTodoS1();
      toggleDone(key);
      Time();
    }
    if (key == 'Level 1') {
      database.setTodo1();
      toggleDone(key);
      Time();
    }
    if (key == 'Level 2') {
      database.setTodo2();
      toggleDone(key);
      Time();
    }
    if (key == 'Level 3') {
      database.setTodo3();
      toggleDone(key);
      Time();
    }
    if (key == 'Level 4') {
      database.setTodo4();
      toggleDone(key);
      Time();
    }
    if (key == 'Level 5') {
      database.setTodo5();
      toggleDone(key);
      Time();
    }
    if (key == 'Level 6') {
      database.setTodo6();
      toggleDone(key);
      Time();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
          stream: database.getTodos(),
          builder: (context, AsyncSnapshot snapshot) {
            if (snapshot.hasData) {
            if ((snapshot.data.data()['Level']) != null) {
              Map<String, dynamic> level =
              snapshot.data!.data()['Level'] as Map<String, dynamic>;
              if(level.length >= 0){
                return Scaffold(
                    appBar: AppBar(
                      title: Center(child: Text('Deine heutigen To-Dos',
                        style: TextStyle(color: Colors.white,
                            fontWeight: FontWeight.bold),)),
                      backgroundColor: Color.fromRGBO(35, 112, 192, 1),
                      actions: [
                        IconButton(onPressed: () => database.deleteTodo(),
                            icon: Icon(
                              Icons.delete_outline, color: Colors.white,))
                      ],),
                    body: ListView.separated(
                        separatorBuilder: (BuildContext context, int index) {
                          return SizedBox(
                            height: 10,
                          );
                        },
                        padding: EdgeInsets.all(10),
                        itemCount: level.length,
                        itemBuilder: (buildContext, i) {
                          String key = level.keys.elementAt(i);
                          return ToDoItem(
                            key,
                            level[key]!,
                                () => toggleDone2(key, level[key]),
                              () => deleteTile(key)
                          );
                        }),
                  floatingActionButton: FloatingActionButton(
                    onPressed: () => newEntry(),
                    backgroundColor: Color.fromRGBO(35, 112, 192, 1),
                    child: Icon(Icons.add),
                  ),
                );
              }
              return Scaffold(
                  appBar: AppBar(
                    title: Center(child: Text('Stufenauswahl', style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline, fontSize: 30),)),
                    backgroundColor: Color.fromRGBO(35, 112, 192, 1),),
                  body: ListView.separated(
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          height: 10,
                        );
                      },
                      padding: EdgeInsets.all(10),
                      itemCount: levels.length,
                      itemBuilder: (buildContext, i) {
                        String key = levels.keys.elementAt(i);
                        return LevelItem(
                          key,
                          levels[key]!,
                              () => toggleDone(key),
                              () => select(key),
                        );
                      }));
            }
             else {
              return Scaffold(
                  appBar: AppBar(
                    title: Center(child: Text('Stufenauswahl', style: TextStyle(
                        color: Colors.white,
                        decoration: TextDecoration.underline, fontSize: 30))),
                    backgroundColor: Color.fromRGBO(35, 112, 192, 1),),
                  body: ListView.separated(
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          height: 10,
                        );
                      },
                      padding: EdgeInsets.all(10),
                      itemCount: levels.length,
                      itemBuilder: (buildContext, i) {
                        String key = levels.keys.elementAt(i);
                        return LevelItem(
                          key,
                          levels[key]!,
                              () => toggleDone(key),
                              () => select(key),
                        );
                      }));
            }
          } else
              return Center(child: CircularProgressIndicator());},
        );
  }
}

class LevelItem extends StatelessWidget {
  final String level;
  final bool value;
  final Function toggleDone;
  final Function select;
  const LevelItem(this.level, this.value, this.toggleDone, this.select);

  @override
  Widget build(BuildContext context) {
    return Card(child: Container(
      height: 70,
      child: Center(
        child: SwitchListTile(
            value: value,
            title: Text(level, style: TextStyle(color: value? Color.fromRGBO(238, 105, 38, 1) : Colors.black),),
            onChanged: (bool value) {
              toggleDone();
              if (value == true) select();
            }),
      ),
    ),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    elevation: 10,
      shadowColor: Color.fromRGBO(238, 105, 38, 1)
    );
  }
}

class ToDoItem extends StatelessWidget {
  final String title;
  final bool done;
  final Function toggleDone2;
  final Function remove;

  const ToDoItem(this.title, this.done, this.toggleDone2, this.remove);

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            border: Border.all(
                width: 5,
                color: done ? Color.fromRGBO(238, 105, 38, 1) : Colors.grey),
            borderRadius: BorderRadius.circular(10)),
        child: ListTile(
          contentPadding: EdgeInsets.symmetric(vertical: 20),
          leading: Checkbox(
            value: done,
            checkColor: Colors.white,
            activeColor: Color.fromRGBO(35, 112, 192, 1),
            onChanged: (bool? value) => toggleDone2(),
          ),
          title: Center(
              child: Text(
                title,
                style: TextStyle(
                    color: done ? Color.fromRGBO(238, 105, 38, 1) : Colors.grey,
                    fontWeight: FontWeight.bold),
              )),
          trailing: IconButton(
            onPressed: () => remove(),
            icon: Icon(Icons.delete_outline, color: Color.fromRGBO(238, 105, 38, 1)),),
          onTap: () {
            Navigator.push<Widget>(
              context,
              MaterialPageRoute<Widget>(
                  builder: (BuildContext context) => NextScreen(done, title)),
            );
          },
          tileColor: Colors.white,
        ));
  }
}


class addItemDialog extends StatefulWidget {
  final void Function(String text) addItem;

  const addItemDialog(this.addItem);

  @override
  _addItemDialogState createState() => _addItemDialogState();
}

class _addItemDialogState extends State<addItemDialog> {
  GlobalKey<FormState> _formKey = GlobalKey();
  late String item;

  void save() {
    if (_formKey.currentState!.validate()) {
      return widget.addItem(item);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        content: Form(
            key: _formKey,
            child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
              TextFormField(
                onChanged: (String text) => item = text,
                onFieldSubmitted: (String text) => save,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Gib ein To-Do-Eintrag ein';
                  }
                  return null;
                },
                decoration: InputDecoration(
                    hintText: 'Gib ein To-do ein',
                    border: OutlineInputBorder(),
                    icon: Icon(
                      Icons.add,
                    )),
              ),
              RaisedButton(
                  onPressed: save,
                  child: Text(
                    'Save',
                    style: TextStyle(color: Colors.white),
                  ),
                  color: Color.fromRGBO(35, 112, 192, 1)),
            ])));
  }
}
