import 'package:akne/etc/Database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TimeSet extends StatefulWidget {
  const TimeSet({Key? key}) : super(key: key);

  @override
  _TimeSetState createState() => _TimeSetState();
}

class _TimeSetState extends State<TimeSet> {
  final GlobalKey<FormState> formKey = GlobalKey();
  DateTime? startDate;
  DateTime? endDate;
  DateTimeRange? dateRange;
  late String text;
  User? user;
  late KalenderService database;

  Future<void> connect() async {
    user = FirebaseAuth.instance.currentUser;
    database = KalenderService(user!.uid);
  }

  String from() {
    if (dateRange == null) {
      return 'Start';
    } else {
      return DateFormat('dd/MM').format(dateRange!.start);
    }
  }

  String until() {
    if (dateRange == null) {
      return 'Ende';
    } else {
      return DateFormat('dd/MM').format(dateRange!.end);
    }
  }

  Future pickDateRange(BuildContext context) async {
    final initialDate = DateTimeRange(
        start: DateTime.now(),
        end: DateTime.now().add(Duration(hours: 3 * 24)));
    final newDateRange = await showDateRangePicker(
        context: context,
        initialDateRange: dateRange ?? initialDate,
        firstDate: DateTime.now(),
        lastDate: DateTime(DateTime.now().year + 5));

    if (newDateRange == null) {
      return;
    } else {
      setState(() {
        dateRange = newDateRange;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        content: Form(
      key: formKey,
      child: Container(
        height: 200,
        width: 300,
        child: Column(children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
                'Wähle eine Zeitspanne aus, inder du die Stufe umsetzt:',
                style: TextStyle(
                    fontSize: 20,
                    color: Color.fromRGBO(35, 112, 192, 1),
                    decoration: TextDecoration.underline)),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Color.fromRGBO(35, 112, 192, 1)),
                  child: Text(from()),
                  onPressed: () => pickDateRange(context),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Icon(
                  Icons.arrow_forward,
                  color: Color.fromRGBO(35, 112, 192, 1),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Color.fromRGBO(35, 112, 192, 1)),
                  child: Text(until()),
                  onPressed: () => pickDateRange(context),
                ),
              ),

            ],
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Transform.scale(
                scale: 0.8,
                child: FloatingActionButton(
                  child: Icon(Icons.check, color: Colors.white),
                  onPressed: () {
                    database.Stufenende(dateRange!.start, dateRange!.end);
                    Navigator.pop(context);
                  },
                  backgroundColor: Colors.green,
                )),
          )
        ]),
      ),
    ));
  }
}