import 'package:akne/etc/Database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class Kalender extends StatefulWidget {

  @override
  _KalenderState createState() => _KalenderState();
}

class _KalenderState extends State<Kalender> {
  User? user;
  late KalenderService database;

  Future connect() async{
    user = FirebaseAuth.instance.currentUser;
    database = KalenderService(user!.uid);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    connect();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: database.getTime(),
      builder: (context, AsyncSnapshot snapshot) {
      if(snapshot.hasData) {
        if (snapshot.data.data()['Stufenzeit'] != null) {
          Map<String, dynamic> time = snapshot.data.data()['Stufenzeit'] as Map<
              String, dynamic>;
        return Scaffold(
            appBar: AppBar(title: Center(
              child: Text(
                'Kalender',
                style: TextStyle(
                    fontSize: 30,
                    color: Colors.white,
                    decoration: TextDecoration.underline),
              ),
            ),
                backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
            body: TableCalendar(
          focusedDay: DateTime.now(),
          firstDay: DateTime.utc(2021, 10, 1),
          lastDay: DateTime.utc(2030, 12, 1),
              rangeStartDay: time['Startdatum'].toDate(),
              rangeEndDay: time['Enddatum'].toDate(),
        ));}
       if(snapshot.data.data()['Stufenzeit'] == null) {
        return Scaffold(
            appBar: AppBar(
              title: Center(
                child: Text(
                  'Kalender',
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                      decoration: TextDecoration.underline),
                ),
              ),
              backgroundColor: Color.fromRGBO(35, 112, 192, 1),
            ),
            body: Center(
                child: Container(
                  height: 200,
                  width: 300,
                  decoration: BoxDecoration(
                      border: Border.all(
                          width: 8, color: Color.fromRGBO(238, 105, 38, 1))),
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Center(
                        child: Text(
                          'Wähle zuerst eine Stufe aus, bevor du den Kalender nutzt.',
                          style:
                          TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.center,
                        )),
                  ),
                )));
      }} return Center(child: CircularProgressIndicator());}
    );
  }
}
