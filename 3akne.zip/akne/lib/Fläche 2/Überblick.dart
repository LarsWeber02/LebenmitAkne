import 'dart:ui';

import 'package:akne/Fl%C3%A4che%203.1/To-Dos.dart';
import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import 'Datenschutz.dart';

class Startseite extends StatefulWidget {

  @override
  State<Startseite> createState() => _StartseiteState();
}

class _StartseiteState extends State<Startseite> {

  YoutubePlayerController _controller = YoutubePlayerController(
    initialVideoId: YoutubePlayer.convertUrlToId("https://youtu.be/gTfXPf83cCM")!,
    flags: YoutubePlayerFlags(
      autoPlay: true,
      mute: false,
      enableCaption: false
    )
  );

  youtubeVideo() {
    showDialog<AlertDialog>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Wie funktioniert die App?',
                style: TextStyle(fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Color.fromRGBO(35, 112, 192, 1),
                decoration: TextDecoration.underline),),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: FittedBox(
                  fit: BoxFit.fill,
                  child: Container(
                  child: YoutubePlayer(
                    controller: _controller,
                    onReady: () {
                  _controller.play();
                  },
                  ),
                ),)
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextButton(
                  child: Text('Datenschutzerklärung'),
                  style: TextButton.styleFrom(primary: Colors.white,
                      backgroundColor: Color.fromRGBO(35, 112, 192, 1)),
                  onPressed: () => Navigator.push(context, MaterialPageRoute(
                    builder: (BuildContext context) => Datenschutz()
                  )),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: IconButton(
                  iconSize: 40,
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(Icons.check),
                  color: Colors.green,
                ),
              )
            ],
          ),
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Center(
              child: Text(
            'Startseite',
            style:
                TextStyle(decoration: TextDecoration.underline, fontSize: 30),
          )),
          backgroundColor: Color.fromRGBO(35, 112, 192, 1),
      ),
      body: SingleChildScrollView(child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
                '1. Inspiziere alle Stufen.\n2. Überlege, welche Stufe du dir zutraust.\n3. Wähle eine Stufe aus.',
                style: TextStyle(
                    color: Color.fromRGBO(35, 112, 192, 1),
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push<Widget>(
                                  context,
                                  MaterialPageRoute<Widget>(
                                      builder: (BuildContext context) =>
                                          ToDo1('Süßigkeiten & süße Getränke')));
                            },
                            child: Text(
                              'Stufe 1',
                              style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(35, 112, 192, 1)),
                            ),
                            style: ElevatedButton.styleFrom(
                                primary: Colors.white,
                                minimumSize: Size(125, 60),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)))),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.8),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 7))
                            ])),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push<Widget>(
                                  context,
                                  MaterialPageRoute<Widget>(
                                      builder: (BuildContext context) =>
                                          ToDo1('Glykämische Last')));
                            },
                            child: Text(
                              'Stufe 3',
                              style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(35, 112, 192, 1)),
                            ),
                            style: ElevatedButton.styleFrom(
                                primary: Colors.white,
                                minimumSize: Size(125, 60),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)))),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.8),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 7))
                            ])),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push<Widget>(
                                  context,
                                  MaterialPageRoute<Widget>(
                                      builder: (BuildContext context) =>
                                          ToDo1('Nährstoffbedarf')));
                            },
                            child: Text(
                              'Stufe 5',
                              style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(35, 112, 192, 1)),
                            ),
                            style: ElevatedButton.styleFrom(
                                primary: Colors.white,
                                minimumSize: Size(125, 60),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)))),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.8),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 7))
                            ])),
                  ),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push<Widget>(
                                  context,
                                  MaterialPageRoute<Widget>(
                                      builder: (BuildContext context) =>
                                          ToDo1('Milchprodukte')));
                            },
                            child: Text(
                              'Stufe 2',
                              style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(35, 112, 192, 1)),
                            ),
                            style: ElevatedButton.styleFrom(
                                primary: Colors.white,
                                minimumSize: Size(125, 60),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)))),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.8),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 7))
                            ])),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push<Widget>(
                                  context,
                                  MaterialPageRoute<Widget>(
                                      builder: (BuildContext context) =>
                                          ToDo1('Fette')));
                            },
                            child: Text(
                              'Stufe 4',
                              style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(35, 112, 192, 1)),
                            ),
                            style: ElevatedButton.styleFrom(
                                primary: Colors.white,
                                minimumSize: Size(125, 60),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)))),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.8),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 7))
                            ])),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                        child: ElevatedButton(
                            onPressed: () {
                              Navigator.push<Widget>(
                                  context,
                                  MaterialPageRoute<Widget>(
                                      builder: (BuildContext context) =>
                                          ToDo1('Kohlenhydrate')));
                            },
                            child: Text(
                              'Stufe 6',
                              style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromRGBO(35, 112, 192, 1)),
                            ),
                            style: ElevatedButton.styleFrom(
                                primary: Colors.white,
                                minimumSize: Size(125, 60),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)))),
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.8),
                                  spreadRadius: 1,
                                  blurRadius: 5,
                                  offset: Offset(0, 7))
                            ])),
                  ),
                ],
              ),
            ],
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Container(
                    child: ElevatedButton(
                        onPressed: () {
                          Navigator.push<Widget>(
                              context,
                              MaterialPageRoute<Widget>(
                                  builder: (BuildContext context) =>
                                      ToDoS()));
                        },
                        child: Text(
                          'Selbstentworfene Stufe',
                          style: TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.bold,
                              color: Color.fromRGBO(35, 112, 192, 1)),
                        ),
                        style: ElevatedButton.styleFrom(
                            primary: Colors.white,
                            minimumSize: Size(330, 60),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)))),
                    decoration: BoxDecoration(
                        border: Border.all(
                            width: 5, color: Color.fromRGBO(238, 105, 38, 1)),
                        borderRadius: BorderRadius.circular(34),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.grey.withOpacity(0.8),
                              spreadRadius: 1,
                              blurRadius: 5,
                              offset: Offset(0, 7))
                        ])),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: TextButton(
                    onPressed: () => youtubeVideo(),
                    child: Text(
                      'Wie funktioniert die App?',
                      style: TextStyle(
                          fontSize: 30,
                          color: Color.fromRGBO(35, 112, 192, 1),
                          decoration: TextDecoration.underline),
                    )),
              ),
            ],
          ),

        ],
      )),
      backgroundColor: Colors.white,
    );
  }
}

